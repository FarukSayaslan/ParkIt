﻿//using Microsoft.AspNetCore.Mvc;
//using ParkIt.Business.Concrete;
//using ParkIt.Models;
//using System.Diagnostics;

using ParkIt.DataAccess.Abstract;
using ParkIt.Entities.Enums;

namespace ParkIt.WebUI.Controllers
{
    internal class RandomParkingDataProvider : IParkingDataProvider
    {
        public List<ParkingStatus> GetParkingStatuses()
        {
            throw new NotImplementedException();
        }
    }
}