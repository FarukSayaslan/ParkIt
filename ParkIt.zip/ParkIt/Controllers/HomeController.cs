using Microsoft.AspNetCore.Mvc;
using ParkIt.Business.Concrete;
using ParkIt.DataAccess.Concrete;

namespace ParkIt.WebUI.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    
        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Developer()
        {
            return View();
        }
    
        public IActionResult OtoparkB()
        {
            var manager = new ParkingManager(new RandomParkingDataProvider());
            var data = manager.GetAllAsync();
            return View(data);
        }

    }
}