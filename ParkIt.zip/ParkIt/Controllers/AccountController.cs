using Microsoft.AspNetCore.Mvc;
using ParkIt.DataAccess.Context;
using ParkIt.Entities.Entities;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;

public class AccountController : Controller
{
    private readonly ParkItDbContext _db;
    private readonly PasswordHasher<User> _hasher = new PasswordHasher<User>();

    public AccountController(ParkItDbContext db)
    {
        _db = db;
    }

    [HttpGet]
    public IActionResult Register() => View();

    [HttpPost]
    public async Task<IActionResult> Register(string userName, string email, string password)
    {
        if (string.IsNullOrWhiteSpace(userName) || string.IsNullOrWhiteSpace(password))
            return View();

        if (await _db.Users.AnyAsync(u => u.UserName == userName))
        {
            ModelState.AddModelError("", "Kullan�c� ad� zaten mevcut.");
            return View();
        }

        var user = new User { UserName = userName, Email = email };
        user.PasswordHash = _hasher.HashPassword(user, password);
        _db.Users.Add(user);
        await _db.SaveChangesAsync();

        await SignInUser(user);
        return RedirectToAction("Index", "Home");
    }

    [HttpGet]
    public IActionResult Login() => View();

    [HttpPost]
    public async Task<IActionResult> Login(string userName, string password)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.UserName == userName);
        if (user == null)
        {
            ModelState.AddModelError("", "Ge�ersiz kullan�c� ad� veya �ifre.");
            return View();
        }

        var res = _hasher.VerifyHashedPassword(user, user.PasswordHash, password);
        if (res == PasswordVerificationResult.Failed)
        {
            ModelState.AddModelError("", "Ge�ersiz kullan�c� ad� veya �ifre.");
            return View();
        }

        await SignInUser(user);
        return RedirectToAction("Index", "Home");
    }

    [HttpPost]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return RedirectToAction("Index", "Home");
    }

    private async Task SignInUser(User user)
    {
        var claims = new[] { new Claim(ClaimTypes.Name, user.UserName), new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()) };
        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        var principal = new ClaimsPrincipal(identity);
        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
    }
}
