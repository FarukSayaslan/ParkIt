﻿using Microsoft.AspNetCore.Mvc;
using ParkIt.DataAccess.Abstract;
using ParkIt.Business.Services;
using System.Text.Json;
using ParkIt.Entities.Entities;
using System.Collections.Generic;
using System.Linq;
using System;

public class ParkingController : Controller
{
    private readonly IParkingSpotDal _parkingSpotDal;
    private readonly GoogleDirectionsService _directionsService;

    public ParkingController(IParkingSpotDal parkingSpotDal, GoogleDirectionsService directionsService)
    {
        _parkingSpotDal = parkingSpotDal;
        _directionsService = directionsService;
    }

    public IActionResult Index()
    {
        return View();
    }

    // Sabit giriş noktası ve park koordinatları
    private static readonly (double lat, double lng) EntryPoint = (37.17820, 33.25196);

    private static readonly List<(string id, double lat, double lng)> StaticParks = new()
    {
        ("P1", 37.17742742213949, 33.25313148196733),
        ("P2", 37.17676770607545, 33.254324635483854),
        ("P3", 37.17775386822612, 33.25305231839172),
        ("P4", 37.17805124297655, 33.25239795158065),
        ("P5", 37.178659509650025, 33.2536412508399),
        ("P6", 37.17643304181604, 33.256130254510275),
        ("P7", 37.17552543621329, 33.2550348088704),
        ("P8", 37.17590690308731, 33.25192161701737),
        ("P9", 37.175844191979714, 33.25144787467846),
        ("P10", 37.17720560314534, 33.25183394408893)
    };

    // Helper: build parks list for map (always include all StaticParks and any DB-only spots)
    private async Task<List<dynamic>> BuildParksListAsync()
    {
        var parkingSpots = await _parkingSpotDal.GetAllAsync();
        var parks = new List<dynamic>();

        var spotsById = (parkingSpots ?? new List<ParkingSpot>())
            .ToDictionary(p => p.Id, StringComparer.OrdinalIgnoreCase);

        // Add/merge static parks (ensures all P1..P10 are present)
        foreach (var s in StaticParks)
        {
            if (spotsById.TryGetValue(s.id, out var p))
            {
                parks.Add(new
                {
                    id = p.Id,
                    lat = s.lat,
                    lng = s.lng,
                    empty = !p.IsOccupied,
                    isOccupied = p.IsOccupied,
                    lastUpdate = p.LastUpdate == default ? DateTime.UtcNow : p.LastUpdate
                });
            }
            else
            {
                // No DB entry: show static spot (mark as empty by default so it's visible)
                parks.Add(new
                {
                    id = s.id,
                    lat = s.lat,
                    lng = s.lng,
                    empty = true,
                    isOccupied = false,
                    lastUpdate = DateTime.UtcNow
                });
            }
        }

        // Add any DB spots that are not in StaticParks
        if (parkingSpots != null)
        {
            foreach (var p in parkingSpots)
            {
                if (!parks.Any(x => string.Equals((string)x.id, p.Id, StringComparison.OrdinalIgnoreCase)))
                {
                    parks.Add(new
                    {
                        id = p.Id,
                        lat = 37.17741574670005 + (p.SpotNumber * 0.00008),
                        lng = 33.25317373597331 - (p.SpotNumber * 0.00005),
                        empty = !p.IsOccupied,
                        isOccupied = p.IsOccupied,
                        lastUpdate = p.LastUpdate == default ? DateTime.UtcNow : p.LastUpdate
                    });
                }
            }
        }

        return parks;
    }

    [HttpGet("api/parking/parks")]
    public async Task<IActionResult> GetParks()
    {
        try
        {
            var parks = await BuildParksListAsync();
            return Ok(parks);
        }
        catch (Exception)
        {
            // Fallback: return static list of all 10 spots
            return Ok(StaticParks.Select(s => new
            {
                id = s.id,
                lat = s.lat,
                lng = s.lng,
                empty = true,
                isOccupied = false,
                lastUpdate = DateTime.UtcNow
            }).ToList<dynamic>());
        }
    }

    [HttpGet("api/parking/entry")]
    public IActionResult GetEntry()
    {
        return Ok(new { lat = EntryPoint.lat, lng = EntryPoint.lng });
    }

    [HttpGet("api/parking/route")]
    public async Task<IActionResult> GetRouteToNearestEmpty()
    {
        try
        {
            var parks = (await BuildParksListAsync()).Select(p => (
                id: (string)p.id,
                lat: (double)p.lat,
                lng: (double)p.lng,
                empty: (bool)p.empty
            )).ToList();

            var emptyParks = parks.Where(p => p.empty).ToList();
            if (!emptyParks.Any()) return NotFound("Boş park yeri yok.");

            var nearest = emptyParks
                .OrderBy(p => GetDistance(EntryPoint.lat, EntryPoint.lng, p.lat, p.lng))
                .First();

            try
            {
                var json = await _directionsService.GetRouteJsonAsync(EntryPoint, (nearest.lat, nearest.lng));
                return Ok(new
                {
                    targetId = nearest.id,
                    directions = JsonDocument.Parse(json).RootElement

                });
            }
            catch (Exception ex)
            {
                return Ok(new
                {
                    targetId = nearest.id,
                    directions = (object?)null,
                    fallbackPoints = new[]
                    {
                        new { lat = EntryPoint.lat, lng = EntryPoint.lng },
                        new { lat = nearest.lat,    lng = nearest.lng }
                    },
                    error = ex.Message
                });
            }
        }
        catch (Exception ex)
        {
            return StatusCode(500, ex.Message);
        }
    }

    [HttpGet("api/parking/routeTo/{id}")]
    public async Task<IActionResult> GetRouteToId(string id)
    {
        try
        {
            var parks = (await BuildParksListAsync()).Select(p => (
                id: (string)p.id,
                lat: (double)p.lat,
                lng: (double)p.lng
            )).ToList();

            var target = parks.FirstOrDefault(p => p.id == id);
            if (target == default) return NotFound();

            var (directionsJson, distanceText, durationText) =
                await _directionsService.GetRouteAndDistanceAsync(EntryPoint, (target.lat, target.lng));

            return Ok(new
            {
                targetId = id,
                directions = JsonDocument.Parse(directionsJson).RootElement,
                distance = distanceText,
                duration = durationText
            });
        }
        catch (Exception ex)
        {
            return StatusCode(500, ex.Message);
        }
    }

    private static double GetDistance(double lat1, double lon1, double lat2, double lon2)
    {
        double R = 6371e3;
        double phi1 = lat1 * Math.PI / 180;
        double phi2 = lat2 * Math.PI / 180;
        double dphi = (lat2 - lat1) * Math.PI / 180;
        double dlambda = (lon2 - lon1) * Math.PI / 180;

        double a = Math.Sin(dphi / 2) * Math.Sin(dphi / 2) +
                   Math.Cos(phi1) * Math.Cos(phi2) *
                   Math.Sin(dlambda / 2) * Math.Sin(dlambda / 2);

        return R * 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
    }
}