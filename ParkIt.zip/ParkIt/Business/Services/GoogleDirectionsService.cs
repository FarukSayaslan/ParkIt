using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Text.Json;

namespace ParkIt.Business.Services
{
    public class GoogleDirectionsService
    {
        private readonly HttpClient _http;
        private readonly IConfiguration _config;
        private readonly ILogger<GoogleDirectionsService> _logger;

        public GoogleDirectionsService(IHttpClientFactory factory, IConfiguration config, ILogger<GoogleDirectionsService> logger)
        {
            _http = factory.CreateClient("google-maps");
            _config = config;
            _logger = logger;
        }

        // Returns the raw JSON from Google Directions API for simplicity.
        public async Task<string> GetRouteJsonAsync((double lat, double lng) origin, (double lat, double lng) destination)
        {

            var apiKey = _config["GoogleMaps:ApiKey"];
            if (string.IsNullOrEmpty(apiKey)) throw new InvalidOperationException("Google Maps API key not configured.");

            var url = $"maps/api/directions/json?origin={origin.lat},{origin.lng}&destination={destination.lat},{destination.lng}&mode=driving&key={apiKey}";

            var res = await _http.GetAsync(url);
            var content = await res.Content.ReadAsStringAsync();

            if (!res.IsSuccessStatusCode)
            {
                _logger.LogWarning("Google Directions HTTP error {StatusCode}: {Content}", res.StatusCode, content);
                throw new InvalidOperationException($"Google Directions HTTP error: {res.StatusCode}");
            }

            try
            {
                using var doc = JsonDocument.Parse(content);
                var root = doc.RootElement;
                var status = root.GetProperty("status").GetString();
                if (!string.Equals(status, "OK", StringComparison.OrdinalIgnoreCase))
                {
                    string errorMessage = root.TryGetProperty("error_message", out var em) ? em.GetString() ?? string.Empty : string.Empty;
                    _logger.LogWarning("Google Directions returned status {Status} - {Error}", status, errorMessage);
                    throw new InvalidOperationException($"Google Directions error: {status} {errorMessage}");
                }
            }
            catch (JsonException je)
            {
                _logger.LogWarning(je, "Failed to parse Google Directions response: {Content}", content);
                throw;
            }

            return content;
        }

        // New: call Directions and Distance Matrix and return combined result
        public async Task<(string DirectionsJson, string DistanceText, string DurationText)> GetRouteAndDistanceAsync((double lat, double lng) origin, (double lat, double lng) destination)
        {
            var apiKey = _config["GoogleMaps:ApiKey"];
            if (string.IsNullOrEmpty(apiKey)) throw new InvalidOperationException("Google Maps API key not configured.");

            // Directions
            string directionsJson = await GetRouteJsonAsync(origin, destination);

            // Distance Matrix
            var dmUrl = $"maps/api/distancematrix/json?units=metric&origins={origin.lat},{origin.lng}&destinations={destination.lat},{destination.lng}&key={apiKey}";
            var dmRes = await _http.GetAsync(dmUrl);
            var dmContent = await dmRes.Content.ReadAsStringAsync();

            if (!dmRes.IsSuccessStatusCode)
            {
                _logger.LogWarning("Google Distance Matrix HTTP error {StatusCode}: {Content}", dmRes.StatusCode, dmContent);
                // Return directions but empty distance/duration
                return (directionsJson, string.Empty, string.Empty);
            }

            try
            {
                using var doc = JsonDocument.Parse(dmContent);
                var root = doc.RootElement;
                var status = root.GetProperty("status").GetString();
                if (!string.Equals(status, "OK", StringComparison.OrdinalIgnoreCase))
                {
                    _logger.LogWarning("Distance Matrix returned status {Status}", status);
                    return (directionsJson, string.Empty, string.Empty);
                }

                var element = root.GetProperty("rows")[0].GetProperty("elements")[0];
                var elemStatus = element.GetProperty("status").GetString();
                if (!string.Equals(elemStatus, "OK", StringComparison.OrdinalIgnoreCase))
                {
                    _logger.LogWarning("Distance Matrix element status {ElemStatus}", elemStatus);
                    return (directionsJson, string.Empty, string.Empty);
                }

                var distanceText = element.GetProperty("distance").GetProperty("text").GetString();
                var durationText = element.GetProperty("duration").GetProperty("text").GetString();

                return (directionsJson, distanceText ?? string.Empty, durationText ?? string.Empty);
            }
            catch (JsonException je)
            {
                _logger.LogWarning(je, "Failed to parse Distance Matrix response: {Content}", dmContent);
                return (directionsJson, string.Empty, string.Empty);
            }
        }
    }
}
