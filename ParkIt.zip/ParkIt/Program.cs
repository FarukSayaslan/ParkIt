﻿using Microsoft.EntityFrameworkCore;
using ParkIt.Business.Abstract;
using ParkIt.Business.Concrete;
using ParkIt.Business.Hubs;
using ParkIt.Business.Services;
using ParkIt.DataAccess.Abstract;
using ParkIt.DataAccess.Concrete;
using ParkIt.DataAccess.Context;
using Microsoft.AspNetCore.Authentication.Cookies;

var builder = WebApplication.CreateBuilder(args);

// =====================
// MVC
// =====================
builder.Services.AddControllersWithViews();

// =====================
// DbContext
// =====================
builder.Services.AddDbContext<ParkItDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        b => b.MigrationsAssembly("ParkIt.WebUI")));

// =====================
// Authentication (cookies)
// =====================
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.LogoutPath = "/Account/Logout";
    });

// =====================
// SignalR
// =====================
builder.Services.AddSignalR();

// =====================
// HttpClient for Google Maps
// =====================
builder.Services.AddHttpClient("google-maps", c =>
{
    c.BaseAddress = new Uri("https://maps.googleapis.com/");
});

// =====================
// Arduino & Broadcast (SINGLETON)
// =====================
builder.Services.AddSingleton<ArduinoReader>(sp =>
    new ArduinoReader("COM8"));   // ← PORT BURADA

builder.Services.AddSingleton<DistanceBroadcastService>();

// =====================
// Business / DAL
// =====================
builder.Services.AddScoped<IParkingSpotDal, EfParkingSpotDal>();
builder.Services.AddScoped<ISensorDal, EfSensorDal>();
//builder.Services.AddScoped<IParkingService, ParkingService>();
builder.Services.AddScoped<ParkIt.Business.Services.GoogleDirectionsService>();

var app = builder.Build();

// =====================
// Middleware
// =====================
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

// =====================
// Endpoints
// =====================
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.MapHub<DistanceHub>("/distanceHub");

// Ensure the singleton is created so it subscribes to ArduinoReader events
app.Services.GetRequiredService<DistanceBroadcastService>();

app.Run();
