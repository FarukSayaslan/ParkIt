// Ensure ParkingService implements IParkingService
using ParkIt.Business.Abstract;
using ParkIt.Business.Concrete.Graph;
using ParkIt.DataAccess.Abstract;
using ParkIt.Entities.Entities;
using ParkIt.Entities.Enums;

public class ParkingService : IParkingService
{
    private readonly ISensorProvider _sensorProvider;
    private readonly Graph _graph;

    public ParkingService(ISensorProvider sensorProvider, Graph graph)
    {
        _sensorProvider = sensorProvider;
        _graph = graph;
    }

    public Task<List<ParkingSpot>> GetAllAsync()
    {
        // Implementation here
        throw new NotImplementedException();
    }

    public Task UpdateFromSensorAsync(string hardwareId, double distance)
    {
        // Implementation here
        throw new NotImplementedException();
    }

    public void HandleParkingStatus(ParkingStatus status)
    {
        // Implementation here
        throw new NotImplementedException();
    }

    public string FindClosestEmpty(string entryNode)
    {
        // Implementation here
        throw new NotImplementedException();
    }

    Task<List<ParkingSpot>> IParkingService.GetAllAsync()
    {
        throw new NotImplementedException();
    }

    //public void HandleParkingStatus(ParkingStatus status)
    //{
    //    switch (status)
    //    {
    //        case ParkingStatus.BOS:
    //            // Logic for when parking is available
    //            Console.WriteLine("Parking is available.");
    //            break;
    //        case ParkingStatus.DOLU:
    //            // Logic for when parking is full
    //            Console.WriteLine("Parking is full.");
    //            break;
    //        case ParkingStatus.ERROR:
    //            // Logic for handling errors
    //            Console.WriteLine("An error occurred with the parking status.");
    //            break;
    //        default:
    //            throw new ArgumentOutOfRangeException(nameof(status), status, null);
    //    }
    //}
}
